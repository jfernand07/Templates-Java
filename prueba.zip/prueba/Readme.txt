Test Module 3 Java Scripts

To get started, you must first install the following: the JSON server and Vite. For these commands, use the following commands:

1. Install Vite
npm install -D vite

2. Initialize package.json
npm init -y

3. package.json
scripts "dev": "vite"

3. Start the local server
npm run dev

This will start a development server using Vite. You can open the app in your browser at: http://localhost:5173

Customization in the JSON file: An administrator was defined

Technologies used:

JavaScript: main program logic
Vite: Fast packager for modern development

How localStorage works in this project
This app uses localStorage to temporarily store the logged-in user. This allows the user to navigate between pages without having to log in each time. The saved value (loggedUser) contains data such as ID, name, email, and role. It can then be retrieved anywhere in the app with:
This storage persists even if the page is reloaded, until the user logs out.

Application Function: In this app, you can log in, edit events, and register. You can use two user types: one as an admi and the other as a visitor.

Roles: Admin vs. User

Users in this app can have a role field that defines their permissions:

admin: Has full access. Can:

View all users.

Create new users.

Edit and delete users from the list.

Access the /newuser path.

user: Has limited access. Can only:

View the list of users.

Cannot edit, delete, or access /newuser.

The role logic is applied both visually (hiding buttons and links) and functionally (blocking protected paths).
